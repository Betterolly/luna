# LUNA: Lunar Atlas

An interactive 3D atlas of the Moon. It draws the lunar surface from NASA Moon Trek map tiles, places named features and landing sites on it, and lets you search, measure and filter by mission year.

The whole application is one file, `index.html`. It runs in a browser with no build step and no server.

> **Status:** This is a student or competition entry in an early state. The imagery pipeline, search and measurement tools work as designed, but the curated coordinate data is only partly verified. See [Data status](#data-status) before quoting any value.

---

## Contents

- [Quick start](#quick-start)
- [Features](#features)
- [Data status](#data-status)
- [Architecture](#architecture)
- [Data sources](#data-sources)
- [Known limitations](#known-limitations)
- [Screenshots](#screenshots)
- [Testing](#testing)
- [Licence and attribution](#licence-and-attribution)

---

## Quick start

**Open locally:** double-click `index.html`, or drag it into a browser window. Internet access is needed for the imagery and the gazetteer.

**Deploy on GitHub Pages:**
1. Create a repository and upload `index.html` and the empty `.nojekyll` file to its root.
2. Go to *Settings → Pages → Deploy from a branch*, choose `main` and `/ (root)`, and save.
3. Open the URL GitHub shows. The page loads its data from the browser, so it works on Pages but not inside a sandbox.

**Requirements:** a current browser with WebGL (Chrome, Firefox, Edge or Safari). Without WebGL the search, record panels and About panel still work.

---

## Features

### The 3D Moon
- Drag to rotate, scroll or press `+` / `-` to zoom, and use the arrow keys to rotate.
- Click or tap a marker to select it and fly the camera to it.
- Hovering over a marker shows a tooltip. Hovering over the surface shows the latitude and longitude under the pointer.
- The Moon turns slowly when idle. This stops on first interaction, and it is off entirely if your system asks for reduced motion.

### Map layers
Choose one from the **Map layer** menu:

| Layer | What it shows | Type |
|---|---|---|
| Imagery: LRO WAC mosaic | Greyscale-style reflectance imagery from the Lunar Reconnaissance Orbiter's wide-angle camera | Measured imagery |
| Colour elevation relief (LOLA) | A colour image of elevation from the Lunar Orbiter Laser Altimeter | Derived from measurements; shown as a colour image |
| Composition: Clementine FeO estimate | A colour-coded estimate of iron oxide content | Derived estimate |
| Custom Trek layer… | Any NASA Moon Trek layer, by its identifier | Unverified; you supply the identifier |

Each layer shows its instrument, data type, source and a note on its limits. A colour legend and a metadata link appear where NASA provides them.

**The LOLA layer is not 3D terrain.** It is a colour image draped on a smooth sphere. The Moon's shape does not change. The app says this on screen, and it isn't claimed anywhere else.

Temperature, hydrogen, gravity and illumination layers appear in the menu but are disabled. Their layer identifiers haven't been verified yet.

### Search
- Search by name, category, agency or alias. Aliases include the traditional names of the maria, such as "Sea of Tranquility" for Mare Tranquillitatis, and site names such as "Shiv Shakti Point".
- Results update as you type. Use the arrow keys and Enter to choose one, or Escape to clear.
- Type coordinates such as `-69.373, 32.319` to fly to any point. Latitude must be between -90 and 90, and longitude between -180 and 360.
- When a matching mission is hidden by the year filter, the status line says so.

### Mission timeline
- The **Missions launched on or before** slider (1966–2026) hides any mission launched after the chosen year.
- Hidden missions disappear from the globe, from search and from nearby lists.
- Selecting a hidden mission, for example from a shared link, moves the slider to its launch year.

### Record panels
Each feature, mission or coordinate opens a side panel with:
- Latitude and longitude
- Agency and date (missions), or diameter (where a size is given)
- Elevation, which is always marked unavailable because no elevation data is loaded
- Coordinate status, accuracy and any conflicting values from other sources
- A description and a link to the source
- A "Live position" line for rovers, which always says they have no live tracking
- The four nearest records in the current view
- A "Copy link to this place" button

### Measurement
- Turn on **Measure distance**, then click two points on the surface.
- The app shows the great-circle distance in kilometres and miles, the two endpoints and the sphere radius used.
- The result is a straight-line distance over a sphere of 1,737.4 km radius. It is not a terrain-following route, and the app says so.

### Other tools
- **Grid:** toggles a latitude and longitude grid.
- **Save image:** saves the current view as a PNG.
- **Global view:** returns to the default view and closes the panel.
- **About and sources:** physical constants, data sources, status-label definitions and limitations.

### Shareable links
- `#place=Tycho` opens a named record.
- `#c=-69.373,32.319` opens a coordinate.
- Malformed links are ignored with a message. The current view is kept.
- Back and forward buttons restore earlier selections.

### Live data
- **Imagery and layers:** loaded from NASA Moon Trek when the page opens and when you change layer.
- **Gazetteer:** the app requests the USGS Gazetteer of Planetary Nomenclature for the Moon when it opens. Names that are already in the curated list are not duplicated. The status line reports how many features were added and how many were skipped, and why.
- If either service is unavailable, the app keeps working with the curated records and the last successful imagery. It says what failed.

### Accessibility and reliability
- The app reads your reduced-motion setting and turns off the spin and fly animations when it is on.
- Search results and panels use ARIA roles and live regions. The keyboard can operate every control.
- Every panel and status message is text, so no information depends only on colour.
- The 3D view recovers from a lost graphics context. If WebGL is unavailable, the rest of the app keeps working.
- The page is hidden or paused when its tab is not visible.

---

## Data status

Every curated record in the app has a status. These are the labels, in plain terms:

- **Source-reported:** the value was seen in a published excerpt from NASA, LROC or another agency. It has **not** been re-checked against the full source.
- **Approximate:** a rounded value, or a value from a secondary source.
- **Unverified:** typed in by hand. Not checked against any authoritative source.

Current position:

- **Curated features (19 craters, maria and mountain ranges):** all **Unverified**. Their centres are approximate values typed in by hand. Do not quote them before checking against the USGS Gazetteer.
- **Landing sites and rover positions (22 missions):** most are **Source-reported** from NASA NSSDC tables or LROC 2016 coordinates. A few are **Approximate** or **Unverified**. Where published sources disagree, both values are recorded in the panel.
- **Live gazetteer features:** the status line reports each request. These records come straight from the USGS response. The endpoint and field names have not been independently checked.
- **Rover positions:** all are historical last-known locations. There is no live tracking for any spacecraft or rover.
- **Imagery alignment:** the orientation of the imagery on the sphere has not been checked against control points. Verify this in a browser before relying on any marker's position relative to the surface.

---

## Architecture

LUNA is a single HTML document. All HTML, CSS and JavaScript are in `index.html`. The only external code is Three.js, which is loaded from a CDN.

### Layout of `index.html`

```
<style>                   Visual system: colour tokens for light and dark, panels, focus rings, reduced-motion rules
<body>                    Canvas, search and control panel, sidebar, tooltip, status footer
<script>
  PURE                    Coordinate, geometry, URL and data-validation functions. No DOM or Three.js.
  DATA                    Curated features (F) and missions (M), with provenance on each record.
  DOM HELPERS             el() for safe element construction, status line, formatting.
  3D                      Scene, Moon sphere, point clouds, picking, camera animation loop.
  TEXTURE LOADING         Per-zoom tile loading with stale-request protection.
  GAZETTEER               Live USGS request, validation and merge into the record list.
  SELECTION               Record panel, year filter, nearest-record search, deep links.
  SEARCH                  Text and coordinate search.
  MEASUREMENT             Spherical great-circle distance and interpolation.
  INPUT                   Pointer, keyboard, wheel and UI bindings.
  START                   Order of initialisation.
</script>
```

The `PURE` block is delimited by comment markers so it can be extracted and tested in Node without a browser.

### Data flow

```
Page load
 ├─ Build UI and layer menu                          (no network)
 ├─ Create WebGL scene                               (falls back to message if unavailable)
 ├─ Load LRO WAC imagery from NASA Moon Trek         (tiles in two zoom levels)
 ├─ Fetch USGS gazetteer (WFS, GeoJSON)              (validate → merge → rebuild feature points)
 └─ Apply URL hash                                    (select record or coordinate)

User actions
 ├─ Drag / wheel / keys → camera quaternion → render on demand
 ├─ Hover → pick points (throttled to one per frame) → tooltip and cursor coordinates
 ├─ Click → pick record → select() → fly, highlight, panel, URL update
 ├─ Year slider → rebuild mission points → update search and selection
 ├─ Layer menu → loadLayer() → tile fetch → texture swap
 └─ Measure → two surface points → great-circle line and distance
```

### Key design decisions

**One file, no build step.** The project can be copied, opened or deployed without installing anything. The trade-off is that the file is large (about 49 KB), and the code is organised by section comments rather than modules.

**Points, not meshes, for features.** Features and missions are drawn as two point clouds rather than individual meshes. This keeps the scene light as the gazetteer grows. Picking uses the raycaster with a small threshold and a front-facing check.

**Missions rebuilt on year change; features built once.** The mission cloud is small, so rebuilding it when the slider moves is cheap. The feature cloud is rebuilt only when the gazetteer loads.

**Render on demand.** The animation loop runs only while the camera is moving or the auto-spin is active. Otherwise the scene is drawn only when something changes. The loop stops when the tab is hidden.

**Each zoom level is tracked separately.** Zoom level 1 is loaded first and gives a quick image. Zoom level 3 replaces it only if at least 90% of its tiles load. A partial high-resolution layer never replaces a complete low-resolution one. Each load has a request token, so a layer change discards any unfinished load from the previous layer.

**Textures are disposed when replaced.** Each new texture frees the one it replaces, so changing layers repeatedly does not accumulate GPU memory.

**Untrusted text is never parsed as HTML.** USGS names, layer names and descriptions are inserted with `textContent` through the `el()` helper. The page contains no `innerHTML`, `outerHTML` or `eval`.

**URL input is validated.** Hash values are decoded safely, length-limited, and matched against a strict pattern before use. Coordinates are range-checked, and longitudes are normalised.

**Spherical maths, not planar.** Distances use the central angle between unit vectors, computed with `atan2` rather than `acos`, so nearly identical and nearly opposite points stay numerically stable. Points along a measured path are interpolated with spherical linear interpolation, with a special case for antipodal points.

**Provenance travels with each record.** Every record carries its source, source URL, status, accuracy, any alternative values and a last-verified field. The record panel shows all of them.

### Coordinate convention

Latitude and longitude are east-positive, in degrees. A point is converted to 3D as:

```
x = cos(lat) · sin(lon)
y = sin(lat)
z = cos(lat) · cos(lon)
```

The 3D Moon uses the same convention. Whether the imagery texture matches this convention has not yet been checked against control points.

### External services

| Service | Used for | Requested by | Fallback |
|---|---|---|---|
| NASA Moon Trek tiles (`trek.nasa.gov/tiles/Moon/EQ/`) | Imagery and colour layers | Browser, per tile | Previous texture kept; status line reports the failure |
| NASA LMMP (`pub.lmmp.nasa.gov`) | Colour legend and metadata link | Browser, when a colour layer is shown | Legend omitted |
| USGS Gazetteer WFS (`astrocloud.wr.usgs.gov`) | Lunar feature names and point coordinates | Browser, once on load, 30-second timeout | Curated records only |

### Limits built into the code

- Tile requests use a 12-second timeout each. Up to six run at once.
- The gazetteer merge stops at 20,000 new records.
- The Moon is a sphere. Elevation is not applied to the surface.

---

## Data sources

- **NASA Moon Trek** (trek.nasa.gov/moon): map tiles for LRO WAC, LOLA and Clementine layers.
- **USGS Gazetteer of Planetary Nomenclature** (planetarynames.wr.usgs.gov): IAU-approved lunar feature names.
- **NASA NSSDC** (nssdc.gsfc.nasa.gov): Apollo and robotic landing-site tables.
- **LROC coordinate tables, 2016** (lroc.asu.edu): human and robotic spacecraft coordinates.
- **NASA NSSDC Moon Fact Sheet**: physical constants shown in the About panel.

LUNA is an independent project. Its curated data is hand-entered and marked with the status labels above.

---

## Known limitations

- **Imagery alignment is unchecked.** The orientation of the texture on the sphere has not been tested against known features.
- **The LOLA layer is a colour image, not terrain.** The surface shape is not derived from elevation data.
- **Most curated feature coordinates are unverified.**
- **Some mission coordinates come from excerpts, not full sources.**
- **The live gazetteer's endpoint and field names are not independently verified.** If USGS changes them, the app falls back to curated records.
- **No live spacecraft tracking.** Rover entries are historical.
- **Measurements are straight-line surface distances** on a sphere. They are not terrain-following routes.
- **No offline mode.** The imagery and gazetteer need an internet connection.
- **Not tested in a browser at the time of writing.** See [Testing](#testing).

---

## Screenshots

Screenshots are not included yet, because they have to be taken in a working browser against the live data. Capture these views and save them in `screenshots/`:

| File | View to capture |
|---|---|
| `01-global-view.png` | Default view with the imagery layer loaded and the status line visible |
| `02-layer-lola.png` | LOLA colour layer with the legend shown, to illustrate the colour relief |
| `03-search-coordinates.png` | Search box with `-69.373, 32.319` typed and the result list visible |
| `04-record-panel-apollo11.png` | Apollo 11 selected, with its panel showing status, source and alternative values |
| `05-year-filter.png` | Year slider set to 1972, with missions after that year hidden |
| `06-measurement.png` | Measurement tool with two points and the distance result |
| `07-deep-link.png` | Browser address bar showing a `#place=` link and the panel open |

Once captured, add the images to this section with standard Markdown, for example `![Global view](screenshots/01-global-view.png)`.

---

## Testing

### Performed

- **JavaScript syntax check** on the full script (passes).
- **Pure-logic tests in Node: 33 checks, all passing.** These cover coordinate round-trips, distance on the equator, the poles and antipodes, spherical interpolation, deep-link parsing, the USGS response validator, and the year filter.
- **Static checks:** every element ID the script uses exists in the markup. No unsafe HTML insertion is used. No inline event attributes are in the markup.

### Not yet performed

- Browser testing of rendering, interaction, search, panels, deep links and the year filter.
- Network testing of tile loading and the gazetteer request.
- Imagery alignment against known control points (Apollo 11, Apollo 17, Chandrayaan-3, Tycho, Shackleton).
- Performance testing with the full gazetteer.
- Testing of WebGL context loss and recovery.

### How to run the pure-logic tests

The tests extract the `PURE` block from `index.html` and run it in Node. They do not need a browser. Run them with Node 18 or later after saving the test script alongside `index.html`.

---

## Licence and attribution

Source code for LUNA: add your chosen licence here before publishing.

Data: NASA and USGS material is generally public domain. Cite the source named in each record panel. The LOLA and LRO WAC imagery should be credited to NASA, LROC and the LOLA team as shown in each layer's metadata link.

Three.js is used under its own licence, loaded from cdnjs.
